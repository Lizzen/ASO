#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

static int breve=0;

int main (int argc, char **argv){
    int opcion;

    while (1){

    
      opcion = getopt_long();

      /* Comprobar si no hay mas opciones */
      if ()
        break;

      switch (opcion)
      {
            
      }
    }






  /* Mostar el resto de argumentos que no son opciones */

}