int main(int argc, char * argv[]){

    int fds[2];
    pid_t pid1,pid2;
    
    
    
    if (pid1 = fork()){
    	if (pid2 = fork()){
        
        
        
    	} else { 
        
        
        
    	} 
    
    } else {
    
    
    
    }

}