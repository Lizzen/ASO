int main(int argc, char *argv[]) {
    DIR *dd;
    struct stat *estado; 
    struct dirent *entrada;
    

    dd = opendir(argv[1]);
    
    while ((entrada= readdir (dd)) != NULL){
    
    	estado = malloc(sizeof(struct stat));
    
        stat(,estado);
    }
}